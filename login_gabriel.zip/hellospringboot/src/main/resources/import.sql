insert into previsao (dia,maxima,minima,humidade,descricao) values ('segunda',32,24,3,'clima extremamente quente');
insert into previsao (dia,maxima,minima,humidade,descricao) values ('terça',31,24,11,'Temperatura altissimaa');
insert into previsao (dia,maxima,minima,humidade,descricao) values ('quarta',34,28,17,'Tempera turaquente mata idoso');
insert into previsao (dia,maxima,minima,humidade,descricao) values ('quinta',25,17,20.,'Frente fria chega em sp');
insert into previsao (dia,maxima,minima,humidade,descricao) values ('sexta',13,8,45,'Temperatura cai e pega paulista de surpresa');
insert into previsao (dia,maxima,minima,humidade,descricao) values ('sabado',15,11,60,'Frente fria veio bem forte dessa vez em paulista');
insert into previsao (dia,maxima,minima,humidade,descricao) values ('sabado',14,5,75,'Pegue seu bobojaco e sua touca, porque hoje faz frio em Sp ');


insert into usuario (id, login, senha) values (1, 'admin', 'admin');