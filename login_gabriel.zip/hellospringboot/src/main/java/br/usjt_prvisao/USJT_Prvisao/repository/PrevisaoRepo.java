package br.usjt_prvisao.USJT_Prvisao.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import br.usjt_prvisao.USJT_Prvisao.model.Previsao;

public interface PrevisaoRepo extends JpaRepository<Previsao, Long>{

}
